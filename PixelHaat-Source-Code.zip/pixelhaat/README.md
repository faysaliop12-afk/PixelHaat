# PixelHaat — digital product shop starter

A single-owner digital shop starter built with Next.js and Supabase. It includes a responsive storefront, product details, email-link authentication, a role-checked admin dashboard, and a database schema designed to keep orders/payment state server-owned.

## Important status

This is a **starter project**, not a live-ready payment store. Payment initiation, payment-provider webhook verification, product upload UI, and paid-order download authorization intentionally fail closed until completed and tested. Do not accept real money until these parts are implemented and verified. There is no seller marketplace or seller payout feature because the selected model is single-seller.

## Requirements

- Node.js 20+
- GitHub account
- Supabase account
- Vercel account (or another Node-compatible host)
- Merchant-approved payment gateway account(s)

## 1. Run locally

1. Download/unzip this project.
2. Create a new GitHub repository named `pixelhaat` and upload these files, or use Git from a computer.
3. In the repository, open `Add file` → `Upload files` and upload the project files/folders. Commit the changes.
4. Open a terminal in the project folder and run:

   ```bash
   npm install
   cp .env.example .env.local
   npm run dev
   ```

5. Visit `http://localhost:3000`.

On Android, GitHub upload works in the browser, but running/building the project is much easier on a computer or a cloud development environment.

## 2. Configure Supabase

1. Create a Supabase project.
2. Open **SQL Editor**, paste `supabase/schema.sql`, and run it.
3. Open **Project Settings → API** and copy the Project URL and publishable/anon key into `.env.local`.
4. Set `SITE_URL` to your local URL during development. Configure the same production URL in Supabase Auth URL settings after deployment.
5. In **Authentication → URL Configuration**, add `http://localhost:3000/auth/callback` and your production callback URL.
6. In **Storage**, create a bucket named `digital-products` and set it to **Private**. Do not create a public policy for the paid files.
7. Start the app and visit `/login`. Sign in with your own email.
8. In Supabase **Authentication → Users**, copy your user UUID. In SQL Editor run:

   ```sql
   update public.profiles set role = 'admin' where id = 'YOUR-USER-UUID';
   ```

9. Visit `/admin`. Only accounts with `profiles.role = 'admin'` can view it. Never expose the service-role key in browser code.

## 3. Add products

The storefront lists rows in `public.products` where `is_published = true`. Until an upload form is implemented, add product metadata using the Supabase Table Editor. Example:

```sql
insert into public.products (title, slug, description, category, price_usd, price_bdt, cover_emoji, is_published)
values ('Mama & Baby PNG', 'mama-baby-png', 'A cute PNG design for your creative projects.', 'PNG', 3.99, 450, '🎨', true);
```

For each paid item, upload the actual file to the private `digital-products` bucket and store its path in `storage_path`. Never put paid file URLs in public product records or on a public bucket.

## 4. Payments — Bangladesh and international

### Bangladesh

SSLCOMMERZ publishes a merchant integration flow with session creation, IPN notification, and Order Validation API. Apply for a merchant account and confirm eligibility, fees, settlement, currencies, and digital-goods policy with SSLCOMMERZ. Start with its sandbox. The current `app/api/sslcommerz/ipn/route.ts` is intentionally a 501 placeholder; it is **not** payment verification.

Before going live, implement all of the following server-side:

- Create a pending order using the price read from Supabase, not a client-supplied price.
- Initiate the SSLCOMMERZ hosted session with unique `tran_id` and callbacks.
- Receive IPN, call the official Order Validation API, and compare transaction ID, exact amount, currency, and status.
- Reject duplicate callbacks/idempotently update the order; review risk-level transactions.
- Mark paid only after successful server validation.

Official docs: https://developer.sslcommerz.com/doc/v4/

### International buyers

Do not assume Stripe is available to a Bangladesh-based merchant. Apply to a payment provider that explicitly onboards Bangladesh-based businesses and supports digital downloads/your product category. Confirm seller-country eligibility and payouts directly with that provider. The international payment route is disabled in this starter until the selected provider's official API and webhook verification are implemented. Do not put an unverified payment link into checkout.

## 5. Secure download flow (must be implemented before launch)

`app/api/download/[productId]/route.ts` currently denies all requests by design. A production implementation must:

1. Verify the signed-in user or match a securely verified guest order.
2. Query the server-side order by user/email and product.
3. Require `status = 'paid'` and verify the product ID matches.
4. Generate a short-lived signed URL from the private Supabase Storage bucket (for example 60 seconds), record a download event, and redirect.
5. Rate-limit repeated requests and avoid exposing storage paths or service keys.

Never grant downloads from a `?success=true` URL or browser redirect alone.

## 6. Deploy to Vercel

1. Push the project to GitHub.
2. In Vercel, choose **Add New → Project**, import the `pixelhaat` repository.
3. Add environment variables from `.env.example` in Vercel Project Settings. Only add server secrets in the server environment; never prefix them with `NEXT_PUBLIC_`.
4. Deploy. Add your deployed URL to Supabase Auth redirect URLs and set `SITE_URL`.
5. Test login, admin role, product listing, and private storage before configuring payments.
6. Use payment sandbox tests, including failed, cancelled, duplicate IPN, wrong amount, and delayed notification cases. Switch to production only after merchant approval and end-to-end verification.

## Security checklist

- Keep `SUPABASE_SERVICE_ROLE_KEY` private.
- Keep the product bucket private.
- Use HTTPS in production.
- Enable MFA on Supabase, GitHub, Vercel, and payment accounts.
- Do not manually mark orders paid based on screenshots or redirects.
- Add privacy policy, terms, refund policy, license terms, contact details, and applicable tax/legal review before selling.
- Back up your database and monitor payment notifications.

## Project structure

```text
app/                     storefront, product, login, admin and API routes
lib/                     Supabase clients and admin checks
supabase/schema.sql      tables, RLS policies and profile trigger
.env.example             environment variable template
```
