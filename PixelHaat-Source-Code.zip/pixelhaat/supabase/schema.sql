-- PixelHaat starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique,
  description text not null default '',
  category text not null default 'Other' check (category in ('PNG','eBook','Template','Printable','Other')),
  price_usd numeric(10,2) not null check (price_usd >= 0),
  price_bdt numeric(12,2) check (price_bdt is null or price_bdt >= 0),
  cover_emoji text not null default '✨',
  storage_path text, -- private bucket path, not a public URL
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references auth.users(id) on delete set null,
  email text not null,
  product_id uuid not null references public.products(id),
  amount numeric(10,2) not null check (amount >= 0),
  currency text not null check (currency in ('USD','BDT')),
  provider text not null,
  provider_transaction_id text unique,
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded','review')),
  paid_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.download_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  downloaded_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.download_events enable row level security;

-- Public can only see published product metadata. storage_path is intentionally excluded.
drop policy if exists "public read published products" on public.products;
create policy "public read published products" on public.products for select using (is_published = true);
-- Authenticated users can read their own profile only. Role changes must be done by trusted admin/service role.
drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
-- No client-side insert/update policies on orders or download_events: payment state is server-owned.
-- No public storage access policy: create a PRIVATE bucket named `digital-products` in Storage.
-- Set the first admin after signing in, replacing with your actual auth user UUID:
-- update public.profiles set role='admin' where id='YOUR-AUTH-USER-UUID';

-- Automatically create a customer profile on signup.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, role) values (new.id, 'customer') on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
