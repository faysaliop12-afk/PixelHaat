import { createSupabaseServerClient } from "@/lib/supabase-server";
export async function requireAdmin() {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { user: null, supabase, isAdmin: false };
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
  return { user, supabase, isAdmin: profile?.role === "admin" };
}
