import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "PixelHaat — Digital Products", description: "Discover digital designs, eBooks, templates and printables." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
