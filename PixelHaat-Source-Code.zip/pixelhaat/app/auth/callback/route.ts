import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase-server";
export async function GET(request: Request) { const url=new URL(request.url); const code=url.searchParams.get('code'); const next=url.searchParams.get('next')||'/admin'; if(code){const supabase=await createSupabaseServerClient(); await supabase.auth.exchangeCodeForSession(code);} return NextResponse.redirect(new URL(next.startsWith('/')?next:'/admin',url.origin)); }
