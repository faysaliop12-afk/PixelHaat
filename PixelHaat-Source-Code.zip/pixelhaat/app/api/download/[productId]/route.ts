import { NextResponse } from "next/server";
// Downloads must be authorized against a verified paid order, then served using a short-lived signed URL.
// This starter deliberately denies all downloads until the verified orders schema + checks are configured.
export async function GET() { return NextResponse.json({ error: "Download unavailable: no verified paid order found or download authorization is not configured." }, { status: 403 }); }
