import { NextResponse } from "next/server";
// IMPORTANT: Never mark an order paid based only on a browser redirect or the IPN's posted status.
// Implement SSLCOMMERZ Order Validation API verification, compare tran_id + amount + currency,
// make updates idempotent, and only then grant access to the purchased product.
export async function POST() { return NextResponse.json({ error: "IPN handler is a safe placeholder. Add server-side SSLCOMMERZ validation before going live." }, { status: 501 }); }
