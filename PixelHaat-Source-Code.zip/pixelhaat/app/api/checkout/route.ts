import { NextResponse } from "next/server";
// Intentionally disabled until a merchant-approved international gateway is selected and implemented.
// Never trust prices from the browser; fetch product prices server-side before creating an order.
export async function POST() { return NextResponse.json({ error: "Checkout is not enabled yet. Configure a supported payment provider and verified webhook first." }, { status: 501 }); }
